import mongoose from "mongoose";

const cartProdutSchema = new mongoose.Schema(
  {
    productId: {
      type: mongoose.Schema.ObjectId,
      ref: "product",
    },
    quantity: {
      type: Number,
      default: 1,
    },
    usedId: {
      type: mongoose.Schema.ObjectId,
      ref: "User",
    },
  },
  {
    timestamps: true,
  }
);

const cartProdutModel = mongoose.model("cartProdut", cartProdutSchema);

export default cartProdutModel;
