import { Resend } from "resend";
import dotenv from "dotenv";
dotenv.config();

// Ensure RESEND_API is set
if (!process.env.RESEND_API) {
  throw new Error("❌ Provide RESEND_API inside the .env file");
}

const resend = new Resend(process.env.RESEND_API);

/**
 * Sends an email using Resend API
 * @param {Object} options
 * @param {string} options.sendTo - recipient email
 * @param {string} options.subject - email subject
 * @param {string} options.html - email HTML content
 */
const sendEmail = async ({ sendTo, subject, html }) => {
  try {
    const { data, error } = await resend.emails.send({
      from: "Blink <onboarding@resend.dev>", // must match verified sender
      to: sendTo,
      subject,
      html,
    });

    if (error) {
      console.error("❌ Email send error:", error);
      return null;
    }

    console.log("✅ Email sent:", data);
    return data;
  } catch (err) {
    console.error("❌ Exception in sendEmail:", err);
    return null;
  }
};

export default sendEmail;
